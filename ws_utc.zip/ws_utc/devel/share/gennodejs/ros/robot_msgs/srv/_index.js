
"use strict";

let ChangeColor = require('./ChangeColor.js')

module.exports = {
  ChangeColor: ChangeColor,
};
