#include "ros/ros.h"
#include <geometry_msgs/Pose2D.h>
#include <robot_msgs/MoveToPoseAction.h>
#include <actionlib/client/simple_action_client.h>

#define PI 3.14159

class ActionClient{
    private:
        ros::NodeHandle nh_;
        actionlib::SimpleActionClient<robot_msgs::MoveToPoseAction> ac_;
        std::vector<geometry_msgs::Pose2D> targets_;
    public:
        ActionClient():ac_("pose_control", true){
            geometry_msgs::Pose2D p1;
            p1.x =  10.0;
            p1.y = 10.0;
            p1.theta = PI;
            targets_.push_back(p1);

            geometry_msgs::Pose2D p2;
            p2.x =  -10.0;
            p2.y = 10.0;
            p2.theta = -PI/2;
            targets_.push_back(p2);

            geometry_msgs::Pose2D p3;
            p3.x = -10.0;
            p3.y = -10.0;
            p3.theta = 2*PI;
            targets_.push_back(p3);


            geometry_msgs::Pose2D p4;
            p4.x =  10.0;
            p4.y = -10.0;
            p4.theta = PI/2;
            targets_.push_back(p4);


        }
        ~ActionClient(){
        }

       void doneCB(const actionlib::SimpleClientGoalState& state,
              const robot_msgs::MoveToPoseResultConstPtr& result)
        {
            ROS_INFO("Finished in state [%s]", state.toString().c_str());
            ROS_INFO_STREAM("Error: d -" << result->distance_error << "angle -" << result->angle_error);
         
        }

        void activeCB()
        {
        // ROS_INFO("Goal just went active");
        }

        void feedbackCB(const robot_msgs::MoveToPoseFeedbackConstPtr& f)
        {

        
            ROS_INFO_STREAM("Process:  " << f->percentage << "%");
        
        }

        void execute(){
            ac_.waitForServer();
            int idx = 0  ;
            while(ros::ok()){
                robot_msgs::MoveToPoseGoal goal;
                goal.target_pose = targets_[idx%4];
                idx++;
                ac_.sendGoal(goal,boost::bind(&ActionClient::doneCB,this,_1,_2),
                boost::bind(&ActionClient::activeCB,this),
                boost::bind(&ActionClient::feedbackCB,this,_1));
                ac_.waitForResult();
                
            }
        }




};
