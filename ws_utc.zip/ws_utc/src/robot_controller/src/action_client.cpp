#include <action_client.h>
int main(int argc, char ** argv)
{
    ros::init(argc, argv,"client");
    ActionClient client;
    client.execute();
    return 1;
}